Please make sure these are checked so we can help you! (put an x in the [ ] to check it)

- [ ] I am running Windows 10, from build 10240 to the current build listed working in the README.md [See here](http://www.windowscentral.com/how-check-your-windows-10-build)
- [ ] I am running the program as administrator

If you are using the command line, please give us the full traceback (any output that include errors you have), or an image of the traceback.

If you are using the GUI version, please make sure you can check this:

- [ ] I have the setting "Show Windows background picture on the sign-in screen" set to on (it is in Personalization->Lock Screen)

Also, please send a screen shot of any error dialog that may show up for the GUI version.

Finally, please provide any other information that you feel is relevant.
